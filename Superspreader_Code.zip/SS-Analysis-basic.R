##################################################################
#R script to analyze assocation of TB cough duration and other variables
#this script looks at individual predictors
#written by Andreas Handel (ahandel@uga.edu). Last change 11/17/2016
##################################################################
rm(list=ls());
library(plyr)
library(dplyr) #for data manipulation - load last


##################################################################
#read data 
#these data files have been processed by previous scripts
#see those scripts for details

logfit = 1 #switch between fitting outcome on linear or log scale

#loop over all data sets
datanames=c('china','peru','gambia','cohsonet','kawempe','steps')

#save results for each dataset in list
#make empty list to hold all studies
reslist = vector("list", length(datanames))
names(reslist) = datanames

MST=rep(0,length(datanames)) #mean square total
SST=MST;

ct=1;
for (dataname in datanames)
{
    
    print(sprintf('***** starting to analyze dataset %s ******',dataname))
  
  
  
  loadfile=paste('../cleandata/data_',dataname,'_clean_completecases.Rdata',sep='')
  load(loadfile); mydata <- eval(parse(text=paste('data_',dataname,'_clean_completecases',sep='')));
  
  
  #save observations/outcome in variable for later easy use
  #name of outcome variable is totalcoughdays
  
  #this does outcome on linear scale
  outcome <- mydata$totalcoughdays; outcomename = 'totalcoughdays'
  filename=paste('../manuscript/results/linresponse-basic-analysis.Rdata',sep='')
  
  #use log-transformed outcome/cough instead
  if (logfit == 1)
  {
    mydata <- dplyr::mutate(mydata, logcoughdays=log(totalcoughdays)) %>% dplyr::select(logcoughdays, everything() ); 
    mydata$totalcoughdays <- NULL; 
    outcome <- mydata$logcoughdays; outcomename = 'logcoughdays';
    filename=paste('../manuscript/results/logresponse-basic-analysis.Rdata',sep='')
  }
  
  predictors <- mydata[,-1]
  
  npred=ncol(predictors) #number of predictors
  nobs=nrow(mydata) # number of observations
  SST[ct] = sum( (outcome - mean(outcome))^2 ) #for R2 computations below
  MST[ct] = SST[ct]/nobs

    ##################################################################
    #doing a univariate regression for each predictor
    #print("******* doing univariate analyses ********")
    var_and_p_R2 = data.frame(varname = colnames(predictors), pval = 0, R2 = 0) #save name of variable and p-value
    
    for (nn in 1:ncol(predictors))
    {
        fitlm_uni = lm(outcome ~ predictors[,nn])
        predicteduni <- predict(fitlm_uni)
        R2fitlm=1 - sum((predicteduni-outcome)^2)/SST[ct]

        ano_res = anova(fitlm_uni, test = "F") #anova table
        
        var_and_p_R2[nn,2]=ano_res[,'Pr(>F)'][1]; #get the p-value
        var_and_p_R2[nn,3]= R2fitlm

    }
  
    var_and_p_uni <- arrange(var_and_p_R2, pval) #sort according to smallest p-value
    var_and_p_uni_sig <- var_and_p_uni[var_and_p_uni$pval<=0.05,]
    
    reslist[[ct]]$unifall=var_and_p_uni
    reslist[[ct]]$unifsig=var_and_p_uni_sig
    
    ##################################################################
    #doing a full linear model
    #print("******* doing a full linear model *******")
    if (logfit == 0)
    {
        fitlm_full <- lm(totalcoughdays ~ ., data=mydata)
    }
    if (logfit == 1)
    {
        fitlm_full <- lm(logcoughdays ~ ., data=mydata)
    }   
    
    predictedlm <- predict(fitlm_full) 
    
    R2fitlm=1 - sum((predictedlm-outcome)^2)/SST[ct]
    residlm_full <- outcome - predictedlm
    maxval <- max(c(predictedlm,outcome))
    
    #plot predicted vs observed
    #plot(predictedlm,observed,xlim=c(0,maxval),ylim=c(0,maxval))
    #lines(0:maxval,0:maxval)
    #plot predicted vs residual
    #plot(predictedlm,residlm_full,ylim=c(-max(residlm_full),max(residlm_full)))
    #lines(seq(min(predictedlm),max(predictedlm),length=nrow(mydata)),rep(0,nrow(mydata)) )
    ano_res = anova(fitlm_full, test = "F") #anova table
    var_and_p_full = data.frame(varname = rownames(ano_res), pval=ano_res[,'Pr(>F)'])
    var_and_p_full <- arrange(var_and_p_full, pval)
    var_and_p_full <- var_and_p_full[1:(nrow(var_and_p_full)-1),] #remove entry for residuals
    var_and_p_full_sig <- var_and_p_full[var_and_p_full$pval<=0.05,]

    reslist[[ct]]$fulllmall=var_and_p_full
    reslist[[ct]]$fulllmsig=var_and_p_full_sig
    reslist[[ct]]$fulllmR2=R2fitlm
    
    #browser()
    ct=ct+1;
} #finish loop over all datasets

#turn list into table that can be placed in manuscript

studylabels = c('China','Peru','The Gambia','U-Cohsonet','U-Kawempe','U-Steps')
unifmat=data.frame(Study=studylabels,Significant.Variables=rep(0,length(datanames)),R.Squared=rep(0,length(datanames)))
fulllmmat=unifmat
for (ct in 1:length(datanames))
{
    unifmat[ct,2]=paste(as.vector(reslist[[ct]]$unifsig$varname), collapse= ', ')
    unifmat[ct,3]=paste(as.vector(round(reslist[[ct]]$unifsig$R2,3)), collapse= ', ')

    fulllmmat[ct,2]=paste(as.vector(reslist[[ct]]$fulllmsig$varname), collapse= ', ')
    fulllmmat[ct,3]=as.numeric(reslist[[ct]]$fulllmR2)
}

save(list=ls(), file=filename)


print('all done')