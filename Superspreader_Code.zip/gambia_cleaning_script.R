##################################################################
#R script to pre-process and clean the raw data from the Gambia  study
#written by Andreas Handel (ahandel@uga.edu). Last change 4/27/2017
##################################################################
rm(list=ls());
graphics.off();
library(plyr) #for data manipulation
library(dplyr) #for data manipulation
library(mice)


##################################################################
#read data from a CSV file
#see the accompanying codebook for details on the data
raw.data=read.csv('../rawdata/gambia-study/gambia_data.csv')

#make a copy of the original data
mydata=raw.data

#rename outcome to be consistent across datasets
smalldat1 <- mydata %>% dplyr::mutate(totalcoughdays = coughduration_days)

#remove observations for individuals that have missing data for outcome of interest (duration of cough) 
smalldat2 <- smalldat1 %>% dplyr::filter( !is.na(totalcoughdays) )

#remove several variables since they have >50% missing
#also drop original outcome
smalldat3 <- smalldat2 %>% dplyr::select( -c(hiv_type,windows,familysize,time_opened_windows,coughduration_days) ) 



#convert most predictors to categorical/factors
allnames <- colnames(smalldat3) 
facvars <- allnames[-which(allnames %in% c('totalcoughdays','age'))] #these are not categorical
x <- which(names(smalldat3) %in% facvars) 
smalldat3[,x] <- lapply(smalldat3[,x], as.factor) 



#rename some variables
smalldat4 <- smalldat3 %>% dplyr::rename(Smoking_status = smoker, HIV = hiv_status, Cavitary_status = cavitary_disease)


smalldat.f <- smalldat4

#place outcome (cough days) in first column
smalldat.sort <- smalldat.f %>% dplyr::select(totalcoughdays, everything() )

#drop any unused factor levels
smalldat.sort <- droplevels(smalldat.sort)


#final name of processed/cleaned data
data_gambia_clean <- smalldat.sort

##################################################################
#save cleaned/processed data to file
#this data file will be used by other scripts
#saving as Rdata to not loose factor coding and such 
save(data_gambia_clean, file='../cleandata/data_gambia_clean.Rdata')



##################################################################
#linear model can't deal with missing values, need to make a dataset for this method that doesn't contain missing
#look at all the missing values
#library(Amelia)
#missmap(data_kawempe)

#check for columns/variables with NA
x=colSums(is.na(data_gambia_clean)) 
print(x) 


##pretty complete dataset
#perform imupation on missing data
data_gambia_imputed <- mice::complete(mice(data_gambia_clean,m=1))


#drop any unused factor levels
data_gambia_clean_completecases <- droplevels(data_gambia_imputed)


##################################################################
#save cleaned/processed data to file
#this data file contains no NA and can be used for linear modeling
#saving as Rdata to not loose factor coding and such 
save(data_gambia_clean_completecases, file='../cleandata/data_gambia_clean_completecases.Rdata')




