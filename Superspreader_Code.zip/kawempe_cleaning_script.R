##################################################################
#R script to pre-process and clean the raw data from the Kawempe study
#The script also adds further variables that can be used in subsequent analyses
#written by Andreas Handel (ahandel@uga.edu). Last change 10/5/2016
##################################################################
rm(list=ls());
graphics.off();
library(plyr)
library(dplyr) #for data manipulation
library(caret)
library(mice)
library(Amelia)

##################################################################
#read data from a CSV file
#see the accompanying codebook for details on the data
raw.data=read.csv('../rawdata/kawempe-study/kawempe_data.csv')

#make a copy of the original data
mydata=raw.data

#rename outcome to be consistent across datasets
smalldat1 <- mydata %>% dplyr::rename(totalcoughdays = cough_duration)

#change all 999 which code for missing values to NA
smalldat1[smalldat1 == 999] <- NA

#remove observations for individuals that have missing outcome data 
smalldat2 <- smalldat1 %>% dplyr::filter( !is.na(totalcoughdays) )

#take out individuals that are not index cases, i.e. remove individuals found through active case finding
smalldat3 <- smalldat2 %>% dplyr::filter( case == 3)

#remove variables that are not useable as predictors for analysis
smalldat4 <- smalldat3 %>% dplyr::select( -c(case,idno,X_merge, peoprmnew, study) ) 

#several variables only have a single value/category, need to be removed
smalldat5 <- smalldat4 %>% dplyr::select( -c(serial, Relation_to_index_case, RFLP_matching) )  

#tribe has too many factor levels, not useful
#Grade of eduction is too similar to education level
smalldat6 <- smalldat5 %>% dplyr::select( -c(tribe, Grade_of_education ))

#only few entries in one of these YES/NO categories, makes predictor not useful and leads to error in CV approach
smalldat7 <- smalldat6 %>% dplyr::select( -c(coprindx, prior_TB, Culture_status ))

#delete variables that are categorized versions of other variables
smalldat8 <- smalldat7 %>% dplyr::select( -c(People_per_room) )

#drop some variables that measure contacts not index cases
smalldat9 <- smalldat8 %>% dplyr::select( - c(Contacts_10mm_at_baseline, Contacts_5mm_at_baseline, Proportion_infected_10mm, Proportion_infected_5mm, TST_induration))

#rename some variables
smalldat10 <- smalldat9 %>% dplyr::rename(Smoking_status = smoker, Smear_status = Smear, Education_level = Education, Alcohol_use = Drinking_status, People_per_room = People_per_room_continuous, Number_of_windows = Window)

smalldat.f <- smalldat10



#ensure variables are properly coded as numeric or factor
fact<-colnames(smalldat.f) #first convert everything to factors, then switch back the few that are numeric
x <- which(names(smalldat.f) %in% fact) 
smalldat.f[,x] <- lapply(smalldat.f[,x], as.factor) 

#converting factors to numeric in R is weird, needs to go through an extra step
#this 1-line function does it
as.numeric.factor <- function(x) {as.numeric(levels(x))[x]} 
num_vars <- smalldat.f %>% dplyr::select(age, BMI, Doors_per_room, Interferon_levels, Number_in_household, Number_of_household_contacts, People_per_room, totalcoughdays, Number_of_windows, weightnew)
nums <- colnames(num_vars)
x <- which(names(smalldat.f) %in% nums) 
smalldat.f[,x] <- lapply(smalldat.f[,x], as.numeric.factor) #change numeric variables back from factor variables 


#place outcome (cough days) in first column
smalldat.sort <- smalldat.f %>% dplyr::select(totalcoughdays, everything() )

#too few entries with smear status 7/scanty, combine with 0/negative
smalldat.sort$Smear_status <- mapvalues(smalldat.sort$Smear_status, c(0,1,2,3,7), c(0,1,2,3,0))


#religion 4 and 5 have too few entries and codebook doesn't define what 5 is
#combine with 6/other such that it's 1/2/3/6 catholic/anglican/muslim/other
smalldat.sort$religion <- mapvalues(smalldat.sort$religion, c(1,2,3,4,5,6), c(1,2,3,6,6,6))

#education level has a few categories with too few entries
#recode into low/high (1/2) education level
smalldat.sort$Education_level <- mapvalues(smalldat.sort$Education_level, c(0,1,2,3,4), c(1,1,2,2,2))


#drop any unused factor levels
smalldat.sort <- droplevels(smalldat.sort)


#final name of processed/cleaned data
data_kawempe_clean <- smalldat.sort

##################################################################
#save cleaned/processed data to file
#this data file will be used by other scripts
#saving as Rdata to not lose factor coding and such 
save(data_kawempe_clean, file='../cleandata/data_kawempe_clean.Rdata')

##################################################################
#linear model can't deal with missing values, need to make a dataset for this method that doesn't contain missing
#look at all the missing values
#missmap(data_kawempe_clean)

#check for columns/variables with NA
x=colSums(is.na(data_kawempe_clean)) 
print(x) 

##lots of missing in weightnew, remove that variable
smalldat_a <- data_kawempe_clean %>% dplyr::select( -c(weightnew) ) 

##also remove "know other TB case" since it has lots of unique missing 
smalldat_b <- smalldat_a %>% dplyr::select( -c(Know_another_TB_case) ) 

##remove IFN  since it has lots of unique missing 
smalldat_c <- smalldat_b %>% dplyr::select( -c(Interferon_levels) ) 

smalldat_final <- smalldat_c

#check again for columns/variables with NA
x=colSums(is.na(smalldat_final)) 
print(x) 
print(sum(complete.cases(smalldat_final)))
print(nrow(smalldat_final))
missmap(smalldat_final)

##still a have missing values in some variable, impute those 
data_kawempe_imputed <- mice::complete(mice(data = smalldat_final, m = 1, defaultMethod = c('rf','rf','rf')))

#drop any unused factor levels
data_kawempe_clean_completecases <- droplevels(data_kawempe_imputed)

##################################################################
#save cleaned/processed data to file
#this data file contains no NA and can be used for linear modeling
#saving as Rdata to not loose factor coding and such 
save(data_kawempe_clean_completecases, file='../cleandata/data_kawempe_clean_completecases.Rdata')



