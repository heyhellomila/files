##################################################################
#R script to generate descriptive table for superspreader paper
#script written by Andreas Handel (ahandel@uga.edu). Last change 12/17/2016
##################################################################
rm(list=ls());
graphics.off();
library(dplyr)
library(tidyr)

##################################################################
#read data from a CSV file
#see the accompanying codebook for details on the data
#this data has been processed by previous scripts
#see those scripts for details

##################################################################
#read COHSONET data
#this data has already been cleaned by running the cleaning/processing scripts
#load('../cleandata/data_cohsonet_clean.Rdata')
load('../cleandata/data_cohsonet_clean_completecases.Rdata')

##################################################################
#read Kawempe data
#load('../cleandata/data_kawempe_clean.Rdata')
load('../cleandata/data_kawempe_clean_completecases.Rdata')

##################################################################
#read TB steps data
#this data has already been cleaned by running the cleaning/processing scripts
#load('../cleandata/data_steps_clean.Rdata')
load('../cleandata/data_steps_clean_completecases.Rdata')

##################################################################
#read Peru data
#this data has already been cleaned by running the cleaning/processing scripts
#load('../cleandata/data_peru_clean.Rdata')
load('../cleandata/data_peru_clean_completecases.Rdata')

##################################################################
#read China data
#this data has already been cleaned by running the cleaning/processing scripts
load('../cleandata/data_china_clean_completecases.Rdata')

##################################################################
#read China data
#this data has already been cleaned by running the cleaning/processing scripts
load('../cleandata/data_gambia_clean_completecases.Rdata')


#compute number of observations and predictors for each study
studynames=c('China','Peru','The Gambia','U-Cohsonet','U-Kawempe','U-Steps')
countrynames=c('China','Peru','The Gambia','Uganda','Uganda','Uganda')


years=c('2014','2010 - 2013', '2002 - 2004', '2012 - 2015', '1995 - 2006', '2014')
setting=c('Hospital','Hospital','Clinics','Hospital','Hospital','Clinics')
design=c('Retrospective Cohort','Household Contact','Household Contact', 'Household Contact','Household Contact','Retrospective Cohort')
diagmeth = c('Smear or culture','Smear or culture','Smear or culture', 'Smear or culture', 'Smear or culture','Smear or culture or clinical features')
#shorten variables of studies to make expressions more compact
s4=data_cohsonet_clean_completecases
s5=data_kawempe_clean_completecases
s6=data_steps_clean_completecases
s2=data_peru_clean_completecases
s1=data_china_clean_completecases
s3=data_gambia_clean_completecases


totind=c(nrow(s1),nrow(s2),nrow(s3),nrow(s4),nrow(s5),nrow(s6))
totpred=c(ncol(s1),ncol(s2),ncol(s3),ncol(s4),ncol(s5),ncol(s6))-1

studytable=data.frame(Studyname=studynames, Country=countrynames, Year=years, Setting=setting, Design=design, Diagnostic_Method = diagmeth, Number_of_Participants=totind, Number_of_Predictors=totpred)

#make a table that shows all variables in the studies
allvars=unique(c(colnames(s1),colnames(s2),colnames(s3),colnames(s4),colnames(s5),colnames(s6)))

s1vars = allvars %in% colnames(s1)
s2vars =  allvars %in% colnames(s2)
s3vars =  allvars %in% colnames(s3)
s4vars =  allvars %in% colnames(s4)
s5vars =  allvars %in% colnames(s5)
s6vars =  allvars %in% colnames(s6)

vartableunsort = data.frame(Variable = allvars, China = s1vars, Peru = s2vars, Gambia = s3vars, "U-Cohsonet" = s4vars, "U-Kawempe" = s5vars, "U-Steps" = s6vars)

si = sort(rowSums(vartableunsort[,2:ncol(vartableunsort)]),index.return=TRUE,decreasing = TRUE)

vartable = vartableunsort[si$ix,]

save(vartable, file='../manuscript/results/vartable.Rdata')


#add some more variables to table

medianage=c(median(s1$age,na.rm=TRUE), 
            NA,
            median(s3$age,na.rm=TRUE),
            median(s4$age,na.rm=TRUE),
            median(s5$age,na.rm=TRUE),
            median(s6$age,na.rm=TRUE))

maxage = c(max(s1$age,na.rm=TRUE), 
           NA,
           max(s3$age,na.rm=TRUE),
           max(s4$age,na.rm=TRUE),
           max(s5$age,na.rm=TRUE),
           max(s6$age,na.rm=TRUE))

minage = c(min(s1$age,na.rm=TRUE), 
           NA,
           min(s3$age,na.rm=TRUE),
           min(s4$age,na.rm=TRUE),
           min(s5$age,na.rm=TRUE),
           min(s6$age,na.rm=TRUE))


smokerpercent=c( sum(s1$Smoking_status!=0,na.rm=TRUE)/sum(!is.na(s1$Smoking_status)), 
                 sum(s2$Smoking_status!=0,na.rm=TRUE)/sum(!is.na(s2$Smoking_status)),
                 sum(s3$Smoking_status!=0,na.rm=TRUE)/sum(!is.na(s3$Smoking_status)),
                 sum(s4$Smoking_status == 1,na.rm=TRUE)/sum(!is.na(s4$Smoking_status)), #cohsonet
                 sum(s5$Smoking_status!=0,na.rm=TRUE)/sum(!is.na(s5$Smoking_status)),
                 sum(s6$Smoking_status!=0,na.rm=TRUE)/sum(!is.na(s6$Smoking_status))
)*100

hivpos=c( NA, #china
          sum(s2$HIV == 1,na.rm=TRUE)/sum(!is.na(s2$HIV)),
          sum(s3$HIV == 1,na.rm=TRUE)/sum(!is.na(s3$HIV)),
          sum(s4$HIV == 1,na.rm=TRUE)/sum(!is.na(s4$HIV)),
          sum(s5$HIV == 1,na.rm=TRUE)/sum(!is.na(s5$HIV)),
          sum(s6$HIV == 1,na.rm=TRUE)/sum(!is.na(s6$HIV))
)*100

smearpos=c( NA, #China 
           sum(s2$Smear_status != 0,na.rm=TRUE)/sum(!is.na(s2$Smear_status)),
           1, # The Gambia
           sum(s4$Smear_status != 0,na.rm=TRUE)/sum(!is.na(s4$Smear_status)), #cohsonet
           sum(s5$Smear_status != 0,na.rm=TRUE)/sum(!is.na(s5$Smear_status)),
           NA #steps
)*100


studytable$Median_Age = medianage
studytable$Age_Range = paste('(',minage,' - ',maxage,')',sep='')
studytable$Percent_Smokers = round(smokerpercent,1)
studytable$Percent_HIV_positive = round(hivpos,1)
studytable$Percent_Smear_positive = round(smearpos,1)

save(studytable, file='../manuscript/results/studytable.Rdata')

#create a table with all cough information
mincough = round(c(min(s1$totalcoughdays),min(s2$totalcoughdays),min(s3$totalcoughdays),min(s4$totalcoughdays),min(s5$totalcoughdays),min(s6$totalcoughdays)),0)
maxcough = round(c(max(s1$totalcoughdays),max(s2$totalcoughdays),max(s3$totalcoughdays),max(s4$totalcoughdays),max(s5$totalcoughdays),max(s6$totalcoughdays)),0)
meancough = round(c(mean(s1$totalcoughdays),mean(s2$totalcoughdays),mean(s3$totalcoughdays),mean(s4$totalcoughdays),mean(s5$totalcoughdays),mean(s6$totalcoughdays)),0)
medcough = round(c(median(s1$totalcoughdays),median(s2$totalcoughdays),median(s3$totalcoughdays),median(s4$totalcoughdays),median(s5$totalcoughdays),median(s6$totalcoughdays)),0)

coughtable = data.frame(Studyname=studynames, Minimum = mincough, Median = medcough, Mean = meancough, Maximum = maxcough)

save(coughtable, file='../manuscript/results/coughtable.Rdata')



