The scripts provided here clean the raw data and produce all the analysis, plots and tables shown in the paper.

Unfortunately, we cannot share the data underlying the analysis. 
As such, it is not possible to run the scripts, only to see how the analysis is performed.

If you are interested in obtaining the underlying data, you can get in touch with me 
and I can coordinate with the "owners" of the data to see if they are willing to share it.
