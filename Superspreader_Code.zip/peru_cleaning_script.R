##################################################################
#R script to pre-process and clean the raw data from the Peru study
#written by Andreas Handel (ahandel@uga.edu). Last change 12/7/2016
##################################################################
rm(list=ls());
graphics.off();
library(plyr) #for data manipulation
library(dplyr) #for data manipulation
library(mice)


##################################################################
#read data from a CSV file
#see the accompanying codebook for details on the data
raw.data=read.csv('../rawdata/peru-study/peru_data.csv')

#make a copy of the original data
mydata=raw.data

#rename outcome to be consistent across datasets
#also convert from weeks to days
smalldat1 <- mydata %>% dplyr::mutate(totalcoughdays = 7 * cough_duration)

#remove observations for individuals that have missing data for outcome of interest (duration of cough) 
smalldat2 <- smalldat1 %>% dplyr::filter( !is.na(totalcoughdays) )

#some individuals report cough duration as 0 weeks
#not sure what that means/how that can happen
#also prevents log-transform of outcome
#for now remove those observations/individuals
smalldat2b <- smalldat2 %>% dplyr::filter( totalcoughdays!=0)

#remove variables that are not useable as predictors for analysis
#also drop original outcome
smalldat3 <- smalldat2b %>% dplyr::select( -c(family_code, cough_duration) ) 

#all predictors are categorical/factors
allnames <- colnames(smalldat3) 
facvars <- allnames[-which(allnames %in% c('totalcoughdays'))] #not categorical
x <- which(names(smalldat3) %in% facvars) 
smalldat3[,x] <- lapply(smalldat3[,x], as.factor) 

#smear grade and smear status are collinear, remove one
smalldat4 <- smalldat3 %>% dplyr::select( -c(smear) )  

#strip the 'index_' part from each variable name since this is annoying/not needed
#smalldat5 <- smalldat4 %>% setNames(gsub("index_","",names(.)))

#rename a few more variables
smalldat6 <- smalldat4 %>% dplyr::rename(Smear_status = Smear_status, Hospitalization = Hospitalized)

smalldat.f <- smalldat6

#place outcome (cough days) in first column
smalldat.sort <- smalldat.f %>% dplyr::select(totalcoughdays, everything() )

#drop any unused factor levels
smalldat.sort <- droplevels(smalldat.sort)


#final name of processed/cleaned data
data_peru_clean <- smalldat.sort

##################################################################
#save cleaned/processed data to file
#this data file will be used by other scripts
#saving as Rdata to not loose factor coding and such 
save(data_peru_clean, file='../cleandata/data_peru_clean.Rdata')



##################################################################
#linear model can't deal with missing values, need to make a dataset for this method that doesn't contain missing
#look at all the missing values
#library(Amelia)
#missmap(data_kawempe)

#check for columns/variables with NA
x=colSums(is.na(data_peru_clean)) 
print(x) 


##pretty complete dataset
#perform imupation on missing data
data_peru_imputed <- mice::complete(mice(data_peru_clean,m=1))


#remove incomplete observations
#data_peru_clean_completecases <- na.omit(data_peru_clean) #drop observations with NA 

#drop any unused factor levels
data_peru_clean_completecases <- droplevels(data_peru_imputed)

#several variables only have a single factor/category, can't be used for modeling and needs to be removed


##################################################################
#save cleaned/processed data to file
#this data file contains no NA and can be used for linear modeling
#saving as Rdata to not loose factor coding and such 
save(data_peru_clean_completecases, file='../cleandata/data_peru_clean_completecases.Rdata')




