##################################################################
#R script to pre-process and clean the raw data from the TB steps study
#The script also adds further variables that can be used in subsequent analyses
#written by Andreas Handel (ahandel@uga.edu). Last change 12/2/2015
##################################################################
rm(list=ls());
graphics.off();
library(plyr) #for data manipulation
library(dplyr) #for data manipulation
library(mice)


##################################################################
#read data from a CSV file
#see the accompanying codebook for details on the data
raw.data=read.csv('../rawdata/steps-study/steps_data.csv')

#make a copy of the original data
data=raw.data
#remove data for individuals that have unreliable outcome data that we were not possible to correct
#specifically, information on outcome is not consistent, total cough duration is less then time spent in diagnostic pathway
#going to the original data did not allow resolution, therefore individuals need to be dropped
data=data[!(data$PartID %in% c(8, 165, 238, 240, 284, 299) ),]

##################################################################
#recode time per step so everything is in units of days
#run over all steptime_unit columns (starting with 2), replace a 2 (coding weeks) with 7, a 3 (coding months) with a 30.4375, then multiply step_time by that value to get time in days
#also compute total time of cough, then substract from time in diagnostic cascade to get time for 1st step, i.e. from onset of symptoms to 1st contact
data$totalcoughdays <- NULL #add new variable

for (n in 1:nrow(data)) #loop over each observation
{
  #recode time between steps to days
  for (cols in seq(67,91,by=2) )
  {
    if (! is.na(data[n,cols]))
    {
      if (data[n,cols]==2) {data[n,cols] <- 7}
      if (data[n,cols]==3) {data[n,cols] <- 30.4375}
      data[n,(cols-1)]=data[n,(cols-1)]*data[n,cols]
    }
  }
 #recode total cough time to days, add to data frame
 totalcoughdays=sum(c(data[n,"duradays"],data[n,"duraweeks"]*7,data[n,"duramonths"]*30.4375),na.rm=TRUE)
 data[n,"totalcoughdays"]=totalcoughdays;
 data[n,"step_time1"]=data[n,"totalcoughdays"]-sum(data[n,seq(66,90,by=2)],na.rm=TRUE) #total days of cough minus time spend in diagnostic pathway should equal the time spend before 1st contact
}
#check: if any value in data$step_time1 is negative, it means something went wrong

##################################################################
#recode step types by combining individual types of steps (e.g. friend, healer, hospital, etc.) into 3 categories
#categories are TB/nonTB/social
#see the BMC paper for more on that
start.col=which(colnames(data)=="step1")
end.col=start.col+13; #14 steps max
for (n in 1:nrow(data)) #loop over all individuals
{
   for (m in start.col:end.col) #loop over all steps, column 50-63 in codebook 
   { 
        if ( data[n,m] %in% c(3,4,6) ) {data[n,m]="TB"}         #Gov't hospital, health center and private hospital
        if ( data[n,m] %in% c(1,2,5,7) ) {data[n,m]="nonTB"}    #Herbal healer, private clinics, drugs stores, village health worker
        if ( data[n,m] %in% c(8:15,88) ) {data[n,m] = "social"} #Parent, spouse, siblings, adult child, other relative, friend, co-worker, neighbor
    }
}



##################################################################
#extract and modify a subset of data for easier handling
#note that step_time1 is the time from step 0 to 1, step_time2 the time from contact 1 to contact 2, etc.
subdata = data[,c(50:63,seq(64,90,by=2))] #this pulls out the types of contacts (50:63) and the time between each contact (64:90)
#add a new column for step "0", i.e. self -> 1st contact. 
subdata=cbind(step0="self",subdata);


##################################################################
#add new columns that show the step-pairs
start.col=which(colnames(subdata)=="step0")
end.col=start.col+13;
for (m in start.col:end.col) #loop over all steps to create empty columns 
{
    stepname=paste('S',as.character(m-1),'.',as.character(m),sep='')
    subdata[stepname]<- 0 #add new columns
}

#loop over individuals
maxstep=rep(0,nrow(subdata)) # record max number of steps for everyone
for (n in 1:nrow(subdata)) #loop over all individuals
{
   for (m in start.col:end.col) #loop over all steps
   { 
       stepname=paste('S',as.character(m-1),'.',as.character(m),sep='')
       stepvalue=paste(as.character(subdata[n,m]),'.',as.character(subdata[n,m+1]),sep='')
       if ((!is.na(subdata[n,m+1]) & is.na(subdata[n,m+2])) | (!is.na(subdata[n,m+1]) & m==end.col) ) #last step, either if next one is NA or if we are at the last step 
       { 
        stepvalue=paste(stepvalue,'final',sep='') #this is the last step, add a "final" designation to the 2nd half of the step
        maxstep[n]=m
       } 
       subdata[n,stepname] = stepvalue #for each new step pair, assign some letter string, e.g. TB.TB or nonTB.social, etc.
    }
}


##################################################################
#add new variables back to data frame 
#we might not actually use those X-X step information, just types of steps
#keep it in here anyway
data <- cbind(data,subdata[,c(1,30:43)])


##################################################################
#loop over everyone
#compute new variables that record the fraction of steps 
#that are of one of the 3 summary types specified above, i.e. social, TB, nonTB
socialfrac = rep(0,length(nrow(data))); nonTBfrac=socialfrac; TBfrac=socialfrac;
for (n in 1:nrow(data)) 
{    
    socialfrac[n] = sum(subdata[n,2:15] == 'social',na.rm=TRUE) / sum(!is.na(subdata[n,2:15]))
    nonTBfrac[n] = sum(subdata[n,2:15] == 'nonTB',na.rm=TRUE) / sum(!is.na(subdata[n,2:15]))
    TBfrac[n] = sum(subdata[n,2:15] == 'TB',na.rm=TRUE) / sum(!is.na(subdata[n,2:15]))
}
data$socialfrac <- socialfrac
data$nonTBfrac <- nonTBfrac
data$TBfrac <- TBfrac




##################################################################
#do some data checks and cleaning/purging
##################################################################

#remove variables that are not useful for analysis
smalldat1 <- data %>% dplyr::select( -c(X:steptime_unit14,S0.1:S13.14) ) #remove variables that contain information on individual steps 
smalldat2 <- smalldat1 %>% dplyr::select( -c(duradays:duramonths,durawks2:tot_coughwks1)) #remove variables that contain cough duration information in various different columns/time units (we only use totalcoughdays as outcome)
smalldat3 <- smalldat2 %>% dplyr::select( -c(PartID,intdate,resoth,symptoth,chronicoth,placediagoth,step0,tbdiag)) #unimportant/not biologically meaningful variables
smalldat4 <- smalldat3 %>% dplyr::select( -c(Stepsequen:TB) ) #variables containing information how many steps of a given type a person took - is summarized in the 'frac' variables
smalldat5 <- smalldat4 %>% dplyr::select( -c(marital,agecat,Stepcount)) #duplicate variables
smalldat6 <- smalldat5 %>% dplyr::select( -c(network1a,network1b)) #not meaningful variables
smalldat7 <- smalldat6 %>% dplyr::select( -c(sharephone)) #variables with lots of NA 
smalldat8 <- smalldat7 %>% dplyr::select( -c(symptom,advicetime,seekadvice,provtime,seekprov)) #not useful predictors for analysis
smalldat9 <- smalldat8 %>% dplyr::select( -c(worktype,laststep_dx) ) #too many categories to be useful
smalldat10 <- smalldat9 %>% dplyr::select( -c(TBfrac) ) #need to remove one of the 'frac' variables to avoid collinearity, since they sum to 1
smalldat11 <- smalldat10 %>% dplyr::select( -c(hivtreat) ) #all but 2 HIV positive are on treatment, having only 2 'no' prevents CV/resampling and variable hasn't much information, therefore remove hivtreat 


smalldat.f <- smalldat11 #final data frame with only variables included that are potentially suitable for model building


#transform to factor variables
fact_vars <- smalldat.f %>% dplyr::select(residence, sex:knowtb, hivstatus1:smoke)
fact<-colnames(fact_vars)
x<-which(names(smalldat.f) %in% fact) #record a list of the indices of df.small of the binomial variable names
smalldat.f[,x] <- lapply(smalldat.f[,x], as.factor) #change continuous variables to factors where indicated

##recode calldoc variable with value 99 which should be 'no'
smalldat.f$calldoc <- mapvalues(smalldat.f$calldoc, c(1,2,99), c(1,2,2))

##recode chronic to no/yes
smalldat.f$chronic <- mapvalues(smalldat.f$chronic, c(1,2,3,88), c(1,2,2,2))

##recode smoking to from  1/2/3 current/previous/never to yes/no 1/0
smalldat.f$smoke <- mapvalues(smalldat.f$smoke, c(1,2,3), c(1,0,0))

##recode HIV fromm Pos/Neg/Unknown to 1/0/99
smalldat.f$hivstatus1 <- mapvalues(smalldat.f$hivstatus1, c('Positive','Negative','Dont Know'), c(1,0,99))


#rename a bunch of variables
smalldat.f <- smalldat.f %>% dplyr::rename(person_suspected_tuberculosis = thinktb, family_suspected_tuberculosis = familytb, knew_about_tuberculosis = knowtb, weekly_income = earn, place_of_diagnosis = placediag, chronic_disease = chronic, owned_cell_phone = phone, called_health_provider_for_help = calldoc)  
smalldat.f <- smalldat.f %>% dplyr::rename(called_family_member_for_help = callfamily, called_any_person_for_help = callhelp, fraction_of_social_contacts_until_diagnosis = socialfrac, fraction_non_tuberculosis_healthprovider_visits_until_diagnosis = nonTBfrac, comorbid = chronic_disease)  

#place outcome (cough days) in first column
smalldat.f <- smalldat.f %>% dplyr::select(totalcoughdays, everything() )

data_steps_clean <- smalldat.f

##################################################################
#save cleaned/processed data to file
#this data file will be used by other scripts
save(data_steps_clean, file='../cleandata/data_steps_clean.Rdata')


##remove incomplete observations
x=colSums(is.na(smalldat.f)) #check for columns/variables with NA
print(x) #since we have almost no missing data, we don't need to do a separate analysis allowing incomplete predictor data
library(Amelia)
missmap(data_steps_clean)

#rename some variables
data_steps_clean2 <- data_steps_clean %>% dplyr::rename(HIV = hivstatus1, Smoking_status = smoke, Marital_status = marital1, Prior_TB = tbepisode, Employment_status = work)


#smoking has 29 NA - do imuptation
data_steps_imputed <- mice::complete(mice(data_steps_clean2,m=1))


data_steps_clean_completecases <- droplevels(data_steps_imputed)


##################################################################
#save cleaned/processed data to file
#this data file will be used by other scripts
save(data_steps_clean_completecases, file='../cleandata/data_steps_clean_completecases.Rdata')