##################################################################
#R script to analyze assocation of TB cough duration and other variables
#using the mlr package for this
#this script looks at linear models and subset selection
#written by Andreas Handel (ahandel@uga.edu). Last change 12/15/2016
##################################################################
rm(list=ls()); #clear workspace

library(parallelMap) #for using multiple processors when running models through mlr
library(mlr) #for analysis
library(plyr)
library(dplyr) #for data manipulation - load last
library(relaimpo) #to do relative variable importance of variables in final model

#initialize multiple cores for parallel processing using mlr
#note that this is actually the number of 'logical processors', which is 2x the number of cores, i.e. 32 on my machine
ncpu=30;
parallelStartSocket(ncpu, show.info=FALSE, level= "mlr.resample")
#parallelStartSocket(ncpu, show.info=FALSE)

myseed=1111; #set random number seed
set.seed(myseed) 


logfit = 1 #switch between fitting outcome on linear or log scale


##################################################################
#read data 
#these data files have been processed by previous scripts
#see those scripts for details

#loop over all data sets
datanames=c('china','peru','gambia','cohsonet','kawempe','steps')

#save results for each dataset in list
#make empty list to hold results for each study
reslist = vector("list", length(datanames))
names(reslist) = datanames
MST=rep(0,length(datanames)) #mean square total

MSE_fullmodel_full=MST; #hold values for full model
R2_fullmodel_full=MST;

ct2=1; #counter over each dataset
for (dataname in datanames) #loop over all studies
{
    
    print(sprintf('***** starting to analyze dataset %s ******',dataname))
    
    loadfile=paste('../cleandata/data_',dataname,'_clean_completecases.Rdata',sep='')
    load(loadfile); mydata <- eval(parse(text=paste('data_',dataname,'_clean_completecases',sep='')));
    
    
    #save observations/outcome in variable for later easy use
    #name of outcome variable is totalcoughdays
    
    #this does outcome on linear scale
    outcome <- mydata$totalcoughdays; outcomename = 'totalcoughdays'
    filename=paste('../manuscript/results/linresponse-lm-selection.Rdata',sep='')
    
    #use log-transformed outcome/cough
    if (logfit == 1)
    {
        mydata <- dplyr::mutate(mydata, logcoughdays=log(totalcoughdays)) %>% dplyr::select(logcoughdays, everything() ); 
        mydata$totalcoughdays <- NULL; 
        outcome <- mydata$logcoughdays; outcomename = 'logcoughdays';
        filename=paste('../manuscript/results/logresponse-lm-selection.Rdata',sep='')
    }
    
    predictors <- mydata[,-1]
    
    npred=ncol(predictors) #number of predictors
    nobs=nrow(mydata) # number of observations
    SST = sum( (outcome - mean(outcome))^2 ) #for R2 computations below
    MST[ct2] = SST/nobs
    
    ##################################################################
    #doing a bit of predictive modeling with mlr
    #print(sprintf('****doing a bit of linear model feature selection with mlr****'))
    
    ## Generate the task, i.e. outcome and predictors to be fit
    mytask = makeRegrTask(id='SSanalysis', data = mydata, target = outcomename)

    #set learner/model
    #learner_name = "regr.glm";
    #mylearner = makeLearner(learner_name, family = 'gaussian')
    learner_name = "regr.lm";
    mylearner = makeLearner(learner_name)
    
    ########################
    #set sampling method for performance evaluation
    sampling_choice = makeResampleDesc("RepCV", reps = 10, folds = 10)
    #sampling_choice = makeResampleDesc("CV", iters = 3)
 
    
    #########################
    #do full linear model with CV
    fullmodel = resample(mylearner, task = mytask, resampling = sampling_choice, show.info = FALSE )
    MSE_fullmodel_full[ct2] = fullmodel$aggr[1]
    R2_fullmodel_full[ct2] = 1 - MSE_fullmodel_full[ct2]/MST[ct2]
    
    
    #########################
    ## Do feature selection
    #########################
    
    tstart=proc.time(); #capture current CPU time
    
    #select_methods=c("sbs","sfbs","sfs","sffs") #do 2 forms of forward and backward selection, just to compare
    select_methods=NULL
    
    seq_res=list(NULL)
    ct=1;
    for (select_method in select_methods)
    {
        ctrl = makeFeatSelControlSequential(method = select_method)
        print(sprintf('doing subset selection with method %s ',select_method))
        
        #do 'pure' feature selection using the resampling scheme specified
        set.seed(myseed) 
        sfeat_res = selectFeatures(learner = mylearner, 
                                task = mytask, 
                                resampling = sampling_choice, 
                                control = ctrl, 
                                show.info = FALSE)
        #analyzeFeatSelResult(sfeat_res)
        #print(sfeat_res)

        #combine feature selection and training/fitting of final chosen model 
        #result should be same as above if random seed is set the same
        #set.seed(myseed) 
        #featlearn = makeFeatSelWrapper(learner = mylearner, 
         #                              resampling = sampling_choice, 
          #                             control = ctrl,
           #                            show.info = FALSE)
        #selmod = train(featlearn, task = mytask)
        #sfeat_res=getFeatSelResult(selmod)
        #print(sfeat_res)
        
      #cross validated performance of selected dataset using the sampling scheme specified      
      #this can give different feature sets each time, therefore not useful
      #r = resample(learner = featlearn, task = mytask, resampling = outer_sampling, measures = list(mse,rsq), models=TRUE, show.info = FALSE)

        #RMSE is minimized, R2 is also computed/reported
        seq_res[[ct]]=sfeat_res; #save results for all sequential selection methods
        
        ct=ct+1;
        #browser()
    }
    
    reslist[[ct2]]$sequential=seq_res #save results from forward and backward selection methods
    
    
    runtime.minutes_SS=(proc.time()-tstart)[[3]]/60; #total time in minutes the optimization took
    print(sprintf('forward/backward subset selection of dataset %s took %f minutes',dataname,runtime.minutes_SS));

    #takes 1min with 30 cores and 10/5 RepCV
    #takes 2min with 30 cores and 20/5 RepCV
    #takes 1min with 3 corses and 5 CV
    
    
    if (1==1) #genetic algorithm, i.e. smart/efficient way of trying to do full subset selection
    {
        print(sprintf('starting GA search'))
        tstart=proc.time(); #capture current CPU time
        maxit_GA=1000L
        ctrl_GA =makeFeatSelControlGA(maxit = maxit_GA)
        ## Select features
        set.seed(myseed) 
        sfeatga_res = selectFeatures(learner = mylearner, 
                                   task = mytask, 
                                   resampling = sampling_choice, 
                                   control = ctrl_GA, 
                                   show.info = FALSE)
        
        #featlearn_ga = makeFeatSelWrapper(learner = mylearner, 
         #                                 resampling = sampling_choice, 
          #                                control = ctrl_GA,
           #                               show.info = FALSE,
            #                              measures = list(rmse,rsq))
        #sfeatsga = train(featlearn_ga, task = mytask)
        #sfeatga_res=getFeatSelResult(sfeatsga)
        #print(sfeatga_res)
        
        #do a fit of best model
        preds = paste(sfeatga_res$x, collapse =" + ")
        if (logfit == 0)
        {
            modform = as.formula(paste("totalcoughdays ~", preds))
        }
        if (logfit == 1)
        {
            modform = as.formula(paste("logcoughdays ~", preds))
        }
        
        fit_final_lm <- lm(modform , data=mydata)
        #fit_final_lm <- glm(modform , data=mydata, family = gaussian())
        #ano_res = anova(fit_final_lm) #anova table
        relimp = relaimpo::calc.relimp(fit_final_lm, type = 'pmvd', rela = TRUE) #compute relative importance
        
        
        runtime.minutes_GA=(proc.time()-tstart)[[3]]/60; #total time in minutes the optimization took
        print(sprintf('GA search of dataset %s took %f minutes',dataname,runtime.minutes_GA));
     
           
        #residual plot for model
        #predict_ga_res <- predict(sfeatsga, newdata=mydata)
        #predict_ga <- predict_ga_res$data$response
        #residlm_full <- outcome - predict_ga
        #maxval <- max(c(predict_ga,outcome))
        #plot predicted vs residual
        #plot(predict_ga,residlm_full,ylim=c(-max(residlm_full),max(residlm_full)))
        #lines(seq(min(predict_ga),max(predict_ga),length=nrow(mydata)),rep(0,nrow(mydata)) )
    } #end GA search
 
    reslist[[ct2]]$ga=sfeatga_res #save GA result
    reslist[[ct2]]$gavarimp = round(relimp$pmvd, digits = 3) * 100
    ct2=ct2+1; #counter over datasets
    
    print(sprintf('***** finished analysis of dataset %s ******',dataname))
    
    #browser()
       
} #end loop over all studies    
    
#turn list into tables that can be placed in manuscript

#tables for each subset selection approach
nst=length(datanames)
studylabels = c('China','Peru','The Gambia','U-Cohsonet','U-Kawempe','U-Steps')
bestgamat=data.frame(Study=studylabels, Model.Variables=rep(0,nst), Variable.Importance = rep(0,nst), MSE=rep(0,nst), Rsquared=rep(0,nst))
bestsbsmat = bestgamat;
bestsfbsmat = bestgamat;
bestsfsmat = bestgamat;
bestsffsmat = bestgamat;
for (ct in 1:nst)
{
    sortimp=sort(reslist[[ct]]$gavarimp, decreasing=TRUE)
    
    bestgamat[ct,2]=paste(as.vector(names(sortimp)), collapse= ', ')
    bestgamat[ct,3]= paste(as.vector(sortimp), collapse = ', ')
    bestgamat[ct,4]=paste(as.vector(reslist[[ct]]$ga$y), collapse= ', ')
    bestgamat[ct,5]= 1 - as.numeric(bestgamat[ct,4])/MST[ct]
    
    if (length(select_methods)>0)
    {
      bestsbsmat[ct,2]=paste(as.vector(reslist[[ct]]$sequential[[1]]$x), collapse= ', ')
      bestsbsmat[ct,4]=paste(as.vector(reslist[[ct]]$sequential[[1]]$y), collapse= ', ')
      bestsbsmat[ct,5]= 1 - as.numeric(bestsbsmat[ct,4])/MST[ct]
  
      bestsfbsmat[ct,2]=paste(as.vector(reslist[[ct]]$sequential[[2]]$x), collapse= ', ')
      bestsfbsmat[ct,4]=paste(as.vector(reslist[[ct]]$sequential[[2]]$y), collapse= ', ')
      bestsfbsmat[ct,5]= 1 - as.numeric(bestsfbsmat[ct,4])/MST[ct]
      
      bestsfsmat[ct,2]=paste(as.vector(reslist[[ct]]$sequential[[3]]$x), collapse= ', ')
      bestsfsmat[ct,4]=paste(as.vector(reslist[[ct]]$sequential[[3]]$y), collapse= ', ')
      bestsfsmat[ct,5]= 1 - as.numeric(bestsfsmat[ct,4])/MST[ct]
      
      bestsffsmat[ct,2]=paste(as.vector(reslist[[ct]]$sequential[[4]]$x), collapse= ', ')
      bestsffsmat[ct,4]=paste(as.vector(reslist[[ct]]$sequential[[4]]$y), collapse= ', ')
      bestsffsmat[ct,5]= 1 - as.numeric(bestsffsmat[ct,4])/MST[ct]
    }
}


#shut down parallel computing framework
parallelStop()

save(list=ls(), file=filename)

print('all done')