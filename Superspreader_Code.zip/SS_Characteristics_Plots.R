##################################################################
#R script to look for signs of superspreaders in 2 TB datasets
#data are from the Kawempe HHC study and the TB Steps study
#see manuscript for more details on these studies
#script written by Andreas Handel (ahandel@uga.edu). Last change 3/12/2016
##################################################################
rm(list=ls());
graphics.off();
library(dplyr)
library(ggplot2)
library(cowplot) #for better multi-panel plotting in ggplot2
library(tidyr)

##################################################################
#read data from a CSV file
#see the accompanying codebook for details on the data
#this data has been processed by previous scripts
#see those scripts for details
#data is named as file
load('../cleandata/data_kawempe_clean.Rdata')

##################################################################
#read TB steps data
#this data has already been cleaned by running the cleaning/processing scripts
load('../cleandata/data_steps_clean.Rdata')

##################################################################
#read COHSONET data
#this data has already been cleaned by running the cleaning/processing scripts
load('../cleandata/data_cohsonet_clean.Rdata')

##################################################################
#read Peru data
#this data has already been cleaned by running the cleaning/processing scripts
load('../cleandata/data_peru_clean.Rdata')

##################################################################
#read China data
#this data has already been cleaned by running the cleaning/processing scripts
load('../cleandata/data_china_clean.Rdata')

##################################################################
#read Gambia data
#this data has already been cleaned by running the cleaning/processing scripts
load('../cleandata/data_gambia_clean.Rdata')


d1=data_china_clean;
d2=data_peru_clean;
d3=data_gambia_clean;
d4=data_cohsonet_clean;
d5=data_kawempe_clean;
d6=data_steps_clean;

studynames=c('China','Peru','The Gambia','U-Cohsonet','U-Kawempe','U-Steps')


load('../manuscript/results/distribution-fit.Rdata') #data for hazard function fits


##################################################################
#make a new data frame for plotting
#create new variables for plotting (cumulative cough, etc.)
IDvec=c(1:nrow(d1), 1:nrow(d2), 1:nrow(d3), 1:nrow(d4), 1:nrow(d5), 1:nrow(d6) ) #IDs for each study - doesn't correpsond to actual ID from study
Coughvec = c(sort(d1$totalcoughdays,decreasing = TRUE) , sort(d2$totalcoughdays,decreasing = TRUE), sort(d3$totalcoughdays,decreasing = TRUE), sort(d4$totalcoughdays,decreasing = TRUE), sort(d5$totalcoughdays,decreasing = TRUE), sort(d6$totalcoughdays,decreasing = TRUE))
StudyIDvec = c(rep(studynames[1],nrow(d1)) , rep(studynames[2],nrow(d2)), rep(studynames[3],nrow(d3)), rep(studynames[4],nrow(d4)), rep(studynames[5],nrow(d5)), rep(studynames[6],nrow(d6)) )

wbshapevec = as.numeric(c(rep(resmat$wbshape[1],nrow(d1)),rep(resmat$wbshape[2],nrow(d2)),rep(resmat$wbshape[3],nrow(d3)),rep(resmat$wbshape[4],nrow(d4)),rep(resmat$wbshape[5],nrow(d5)),rep(resmat$wbshape[6],nrow(d6)) ))

wbscalevec = as.numeric(c(rep(resmat$wbscale[1],nrow(d1)),rep(resmat$wbscale[2],nrow(d2)),rep(resmat$wbscale[3],nrow(d3)),rep(resmat$wbscale[4],nrow(d4)),rep(resmat$wbscale[5],nrow(d5)),rep(resmat$wbscale[6],nrow(d6)) ))

plot_data = data.frame( PersonID = IDvec, DaysofCough = Coughvec, Study = StudyIDvec, LogDaysofCough = log(Coughvec), wbshape = wbshapevec, wbscale = wbscalevec) 
plot_data <- plot_data %>% group_by(Study) %>% arrange(desc(DaysofCough)) #sort data for each study by descending cough duration
plot_data <- plot_data %>% group_by(Study) %>% mutate(CumDaysofCough = cumsum(DaysofCough)  ) #compute cumulative cough duration for each study
plot_data <- plot_data %>% group_by(Study) %>% mutate(CumFixedCough = cumsum(rep(mean(DaysofCough),n() )) ) #if everyone coughed exactly the same length - note that if you get a weird 'error in n() - this function should not be called directly' message, try to restart R and run this script on a new session. something weird about dplyr/n() - google it on stackoverflow
plot_data <- plot_data %>% group_by(Study) %>% mutate(CumPoisCough = cumsum(sort(rpois(n(),lambda = ceiling(mean(DaysofCough))),decreasing=TRUE))) #if cough duration was possion distributed
plot_data <- plot_data %>% group_by(Study) %>% mutate(CumExpCough = cumsum(sort(rexp(n(), rate = 1/mean(DaysofCough)),decreasing=TRUE))) #if cough duration was possion distributed
plot_data <- plot_data %>% group_by(Study) %>% mutate(CumGeomCough = cumsum(sort(rgeom(n(),prob = 1/mean(DaysofCough)),decreasing=TRUE))) #if cough duration was possion distributed
plot_data <- plot_data %>% group_by(Study) %>% mutate(CumwbCough = cumsum(sort(rweibull(n(),shape = wbshapevec, scale = wbscalevec),decreasing=TRUE))) #if cough duration was possion distributed
plot_data <- plot_data %>% group_by(Study) %>% mutate(PercDaysofCough = CumDaysofCough / max(CumDaysofCough) * 100) 
plot_data <- plot_data %>% group_by(Study) %>% mutate(PercPatients = PersonID / max(PersonID) * 100 ) 
plot_data$Study <- factor(plot_data$Study, levels = studynames)

###################################################################################
#generate plots
###################################################################################


###################################################################################
#histogram for cough duration from all studies
#p1 <- ggplot(plot_data, aes(x=DaysofCough, color=Study)) + geom_histogram(fill="white", alpha=0.5, position="dodge")

#histogram and density plot
p1coughdist <- ggplot(plot_data, aes(x=DaysofCough, color=Study)) + geom_histogram(aes(y=..density..),fill='white') + geom_density( alpha=0) + labs(x = "Days of Cough", y = "Density" , size = 1.5) + facet_wrap(~ Study, nrow = 2)
save_plot("../manuscript/results/cough_density.png", p1coughdist, base_aspect_ratio = 2.2) #cowplot way of saving

#box/violin plot of cough distribution
p2coughdist <- ggplot(plot_data, aes(x=Study, y=DaysofCough, color=Study)) + geom_violin()  + geom_boxplot(width= .05) + stat_summary(fun.y=mean, geom="point", size=2, color="black") 
save_plot("../manuscript/results/cough_plot.png", p2coughdist, base_aspect_ratio = 2.2) #cowplot way of saving

#combined_plots <- plot_grid(p1coughdist,p2coughdist, labels = c("A", "B"), align = "h")
#plot(combined_plots)
#save_plot("../manuscript/results/cough_plot.png", combined_plots, base_aspect_ratio = 3) #cowplot way of saving

#ggsave(filename="../manuscript/results/cough_plot.png",plot=p2coughdist) #ggplot way of saving



###################################################################################
#plot of cumulative cough time as function of persons for Kawempe data

plot_kawempe <- plot_data %>% filter(Study == 'U-Kawempe')
nobs = nrow(plot_kawempe)
maxcough = max(plot_kawempe$CumDaysofCough)

p1 <-  ggplot(plot_kawempe, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2 <- p1 + geom_line( aes(y=CumFixedCough), colour='gray', size=1.5, linetype = 'dotted' )
p3 <- p2 + labs(title = 'U-Kawempe', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p4 <- p3 #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumGeomCough), colour='green', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumPoisCough), colour='orange', size=1.5, linetype = 'solid' ) 
p6 <- p4 + theme(legend.position="none") #+ scale_colour_manual(values=c("#999999", "#E69F00", "#56B4E9"),  name="Scenario", breaks=c("CumDaysofCough", "CumFixedCough", "CumPoissonCough"), labels=c("Data", "Fixed", "Poisson"))
p7 <- p6 + geom_segment(aes(x = floor(nobs*0.2), y = 1, xend = floor(nobs*0.2), yend = floor(maxcough*0.5) ), colour = "red", linetype="dashed", size=1)
p8 <- p7 + geom_segment(aes(x = floor(nobs*0.5), y = 1, xend = floor(nobs*0.5), yend = floor(maxcough*0.8) ), colour = "red", linetype="dashed", size=1)
p9 <- p8 + geom_segment(aes(x = 1, y = floor(maxcough*0.5), xend = floor(nobs*0.2), yend = floor(maxcough*0.5) ), colour = "red", linetype="dashed", size=1)
p10k <- p9 + geom_segment(aes(x = 1, y = floor(maxcough*0.8), xend = floor(nobs*0.5), yend = floor(maxcough*0.8) ), colour = "red", linetype="dashed", size=1)

#plot(p10)



###################################################################################
#plot of cumulative cough time as function of persons for Steps data

plot_steps <- plot_data %>% filter(Study == 'U-Steps')
nobs_steps = nrow(plot_steps)
maxcough_steps = max(plot_steps$CumDaysofCough)

p1s <-  ggplot(plot_steps, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2s <- p1s + geom_line( aes(y=CumFixedCough), colour='gray' , size=1.5, linetype = 'dotted')
p3s <- p2s #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumwbCough), colour='green', size=1.5, linetype = 'dashed' ) 
p4s <- p3s + labs(title = 'U-Steps', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p6s <- p4s + theme(legend.position="none") 
p7s <- p6s + geom_segment(aes(x = floor(nobs_steps*0.2), y = 1, xend = floor(nobs_steps*0.2), yend = floor(maxcough_steps*0.5) ), colour = "red", linetype="dashed", size=1)
p8s <- p7s + geom_segment(aes(x = floor(nobs_steps*0.5), y = 1, xend = floor(nobs_steps*0.5), yend = floor(maxcough_steps*0.8) ), colour = "red", linetype="dashed", size=1)
p9s <- p8s + geom_segment(aes(x = 1, y = floor(maxcough_steps*0.5), xend = floor(nobs_steps*0.2), yend = floor(maxcough_steps*0.5) ), colour = "red",  linetype="dashed", size=1)
p10s <- p9s + geom_segment(aes(x = 1, y = floor(maxcough_steps*0.8), xend = floor(nobs_steps*0.5), yend = floor(maxcough_steps*0.8) ), colour = "red",  linetype="dashed", size=1)

#plot(p10s)

###################################################################################
#plot of cumulative cough time as function of persons for Cohsonet data

plot_cohsonet <- plot_data %>% filter(Study == 'U-Cohsonet')
nobs_cohsonet = nrow(plot_cohsonet)
maxcough_cohsonet = max(plot_cohsonet$CumDaysofCough)


p1c <-  ggplot(plot_cohsonet, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2c <- p1c + geom_line( aes(y=CumFixedCough), colour='gray' , size=1.5, linetype = 'dotted')
p3c <- p2c #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumGeomCough), colour='green', size=1.5, linetype = 'dashed' ) 
p4c <- p3c + labs(title = 'U-Cohsonet', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p6c <- p4c + theme(legend.position="none")
p7c <- p6c + geom_segment(aes(x = floor(nobs_cohsonet*0.2), y = 1, xend = floor(nobs_cohsonet*0.2), yend = floor(maxcough_cohsonet*0.5) ), colour = "red", linetype="dashed", size=1)
p8c <- p7c + geom_segment(aes(x = floor(nobs_cohsonet*0.5), y = 1, xend = floor(nobs_cohsonet*0.5), yend = floor(maxcough_cohsonet*0.8) ), colour = "red", linetype="dashed", size=1)
p9c <- p8c + geom_segment(aes(x = 1, y = floor(maxcough_cohsonet*0.5), xend = floor(nobs_cohsonet*0.2), yend = floor(maxcough_cohsonet*0.5) ), colour = "red",  linetype="dashed", size=1)
p10c <- p9c + geom_segment(aes(x = 1, y = floor(maxcough_cohsonet*0.8), xend = floor(nobs_cohsonet*0.5), yend = floor(maxcough_cohsonet*0.8) ), colour = "red",  linetype="dashed", size=1)

#plot(p10c)


###################################################################################
#plot of cumulative cough time as function of persons for Peru data

plot_peru <- plot_data %>% filter(Study == 'Peru')
nobs_peru = nrow(plot_peru)
maxcough_peru = max(plot_peru$CumDaysofCough)


p1p <-  ggplot(plot_peru, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2p <- p1p + geom_line( aes(y=CumFixedCough), colour='gray' , size=1.5, linetype = 'dotted')
p3p <- p2p #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumGeomCough), colour='green', size=1.5, linetype = 'dashed' ) 
p4p <- p3p + labs(title = 'Peru', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p6p <- p4p + theme(legend.position="none")

p7p <- p6p + geom_segment(aes(x = floor(nobs_peru*0.2), y = 1, xend = floor(nobs_peru*0.2), yend = floor(maxcough_peru*0.5) ), colour = "red", linetype="dashed", size=1)
p8p <- p7p + geom_segment(aes(x = floor(nobs_peru*0.5), y = 1, xend = floor(nobs_peru*0.5), yend = floor(maxcough_peru*0.8) ), colour = "red", linetype="dashed", size=1)
p9p <- p8p + geom_segment(aes(x = 1, y = floor(maxcough_peru*0.5), xend = floor(nobs_peru*0.2), yend = floor(maxcough_peru*0.5) ), colour = "red",  linetype="dashed", size=1)
p10p <- p9p + geom_segment(aes(x = 1, y = floor(maxcough_peru*0.8), xend = floor(nobs_peru*0.5), yend = floor(maxcough_peru*0.8) ), colour = "red",  linetype="dashed", size=1)



###################################################################################
#plot of cumulative cough time as function of persons for China data

plot_china <- plot_data %>% filter(Study == 'China')
nobs_china = nrow(plot_china)
maxcough_china = max(plot_china$CumDaysofCough)


p1ch <-  ggplot(plot_china, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2ch <- p1ch + geom_line( aes(y=CumFixedCough), colour='gray' , size=1.5, linetype = 'dotted')
p3ch <- p2ch #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumGeomCough), colour='green', size=1.5, linetype = 'dashed' )
p4ch <- p3ch + labs(title = 'China', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p6ch <- p4ch + theme(legend.position="none")

p7ch <- p6ch + geom_segment(aes(x = floor(nobs_china*0.2), y = 1, xend = floor(nobs_china*0.2), yend = floor(maxcough_china*0.5) ), colour = "red", linetype="dashed", size=1)
p8ch <- p7ch + geom_segment(aes(x = floor(nobs_china*0.5), y = 1, xend = floor(nobs_china*0.5), yend = floor(maxcough_china*0.8) ), colour = "red", linetype="dashed", size=1)
p9ch <- p8ch + geom_segment(aes(x = 1, y = floor(maxcough_china*0.5), xend = floor(nobs_china*0.2), yend = floor(maxcough_china*0.5) ), colour = "red",  linetype="dashed", size=1)
p10ch <- p9ch + geom_segment(aes(x = 1, y = floor(maxcough_china*0.8), xend = floor(nobs_china*0.5), yend = floor(maxcough_china*0.8) ), colour = "red",  linetype="dashed", size=1)




###################################################################################
#plot of cumulative cough time as function of persons for Gambia data

plot_gambia <- plot_data %>% filter(Study == 'The Gambia')
nobs_gambia = nrow(plot_gambia)
maxcough_gambia = max(plot_gambia$CumDaysofCough)


p1g <-  ggplot(plot_gambia, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2g <- p1g + geom_line( aes(y=CumFixedCough), colour='gray' , size=1.5, linetype = 'dotted')
p3g <- p2g #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumGeomCough), colour='green', size=1.5, linetype = 'dashed' )
p4g <- p3g + labs(title = 'The Gambia', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p6g <- p4g + theme(legend.position="none")

p7g <- p6g + geom_segment(aes(x = floor(nobs_gambia*0.2), y = 1, xend = floor(nobs_gambia*0.2), yend = floor(maxcough_gambia*0.5) ), colour = "red", linetype="dashed", size=1)
p8g <- p7g + geom_segment(aes(x = floor(nobs_gambia*0.5), y = 1, xend = floor(nobs_gambia*0.5), yend = floor(maxcough_gambia*0.8) ), colour = "red", linetype="dashed", size=1)
p9g <- p8g + geom_segment(aes(x = 1, y = floor(maxcough_gambia*0.5), xend = floor(nobs_gambia*0.2), yend = floor(maxcough_gambia*0.5) ), colour = "red",  linetype="dashed", size=1)
p10g <- p9g + geom_segment(aes(x = 1, y = floor(maxcough_gambia*0.8), xend = floor(nobs_gambia*0.5), yend = floor(maxcough_gambia*0.8) ), colour = "red",  linetype="dashed", size=1)






combined_plots <- plot_grid(p10ch,p10p,p10g,p10c,p10k,p10s, labels = c("A", "B", "C", "D", "E",'F'), align = "v", nrow =2)
plot(combined_plots)
save_plot("../manuscript/results/cumulativecough_plot.png", combined_plots, base_aspect_ratio = 3, nrow = 2) #cowplot way of saving





###################################################################################
#plot percent of cumulative cough time as function of persons for all studies

p1c <-  ggplot(plot_data, aes(x=PercPatients, y=PercDaysofCough, colour=Study, linetype=Study) ) + geom_line( size = 1.25) 
p2c <- p1c + labs(x = "Percent of Patients", y = "Percent cumulative days of cough" , size = 1.5) + theme(legend.key.width = unit(3,"line"))

p7c <- p2c + geom_segment(aes(x = 20, y = 0, xend = 20, yend = 50 ), colour = "red", linetype="dashed", size=1)
p8c <- p7c + geom_segment(aes(x = 50, y = 0, xend = 50, yend = 80 ), colour = "red", linetype="dashed", size=1)
p9c <- p8c + geom_segment(aes(x = 0, y = 50, xend = 20, yend = 50 ), colour = "red",  linetype="dashed", size=1)
p10c <- p9c + geom_segment(aes(x = 0, y = 80, xend = 50, yend = 80 ), colour = "red",  linetype="dashed", size=1)

save_plot("../manuscript/results/perc_plot.png", p10c, base_aspect_ratio = 1.5) #cowplot way of saving



###################################################################################
#for steps data, make univariate plots for most important predictors
# u1 <- ggplot(data_steps, aes(x=placediag, y=totalcoughdays, fill=placediag)) + geom_boxplot()
# u2 <- ggplot(data_steps, aes(x=hivstatus1, y=totalcoughdays, fill=hivstatus1)) + geom_boxplot()
# u3 <- ggplot(data_steps, aes(x=nonTBfrac, y=totalcoughdays)) + geom_point()
# u4 <- ggplot(data_steps, aes(x=phone, y=totalcoughdays)) + geom_boxplot()
# univar_steps_plot <- plot_grid(u1,u2,u3,u4, nrow=2)
# plot(univar_steps_plot)
# save_plot("univar_steps_plot.png", univar_steps_plot, base_aspect_ratio = 2) #cowplot way of saving

###################################################################################
#for Kawempe data, make plot to look at difference in cough distribution between index, co-prevalent and incident cases
#case=1 these individuals are co-prevalent, 
#if case=2 these individuals are incident, 
#if case=3 these individuals are index cases
#p1 <- ggplot(data_hhc, aes(x=totalcoughdays, color=case)) + geom_density()
#p2 <- ggplot(data_hhc, aes(x=totalcoughdays, color=case, fill=case)) + geom_histogram(aes(y=0.5*..density..), position ='dodge')
#p3 <- ggplot(data_hhc, aes(x=case, y=totalcoughdays, color=case)) + geom_violin()
#coughtype_plot <- plot_grid(p1,p2,p3, nrow=1)
#plot(coughtype_plot)
#save_plot("coughtype_plot.png", coughtype_plot, base_aspect_ratio = 3) #cowplot way of saving

